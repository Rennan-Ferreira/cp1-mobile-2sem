package com.example.aula_calculadora

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        var primeiroNumero : EditText = findViewById(R.id.editTxtPrimeiroNum)
        var segundoNumero : EditText = findViewById(R.id.editTxtSegundoNum)
        var btnSomar:ImageButton = findViewById(R.id.imageButton)
        var txtResultado : TextView = findViewById(R.id.textViewResultado)

        btnSomar.setOnClickListener{
            var resultado = primeiroNumero.text.toString().toDouble() + segundoNumero.text.toString().toDouble()
            txtResultado.setText("Resultado da soma: $resultado")
//            println("Resultado da soma: $resultado")
        }
    }
}